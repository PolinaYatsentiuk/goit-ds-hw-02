-- 1 task
SELECT * 
FROM tasks 
WHERE user_id = 2;

-- 2 task
SELECT * 
FROM tasks 
WHERE status_id = (SELECT id FROM status WHERE name = 'new');

-- 3 task
UPDATE tasks 
SET status_id = (SELECT id FROM status WHERE name = 'in progress')
WHERE id = 3;

-- 4 task
SELECT * 
FROM users 
WHERE id NOT IN (SELECT user_id FROM tasks);

-- 5 task
INSERT INTO tasks (title, description, status_id, user_id) 
VALUES ('Новий заголовок', 'Опис завдання', (SELECT id FROM status WHERE name = 'new'), 5);

-- 6 task
SELECT * 
FROM tasks 
WHERE status_id != (SELECT id FROM status WHERE name = 'completed');

-- 7 task
DELETE FROM tasks 
WHERE id = 2;

-- 8 task
SELECT * 
FROM users 
WHERE email LIKE '%example.com';

-- 9 task
UPDATE users 
SET fullname = 'Anna X' 
WHERE id = 2;

-- 10 task
SELECT status.name, COUNT(tasks.id) AS task_count 
FROM tasks 
JOIN status ON tasks.status_id = status.id 
GROUP BY status.name;

-- 11 task
SELECT tasks.* 
FROM tasks 
JOIN users ON tasks.user_id = users.id 
WHERE users.email LIKE '%@example.com';

-- 12 task
SELECT * 
FROM tasks 
WHERE description IS NULL;

-- 13 task
SELECT users.fullname, tasks.title 
FROM tasks 
JOIN users ON tasks.user_id = users.id 
JOIN status ON tasks.status_id = status.id 
WHERE status.name = 'in progress';

-- 14 task
SELECT users.fullname, COUNT(tasks.id) AS task_count 
FROM users 
LEFT JOIN tasks ON users.id = tasks.user_id 
GROUP BY users.fullname;