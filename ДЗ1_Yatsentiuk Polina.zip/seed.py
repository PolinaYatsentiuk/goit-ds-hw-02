import sqlite3
from faker import Faker
import random

def create_db():
    with open('db.sql', 'r') as f:
        sql = f.read()

    with sqlite3.connect('main.db') as con:
        cur = con.cursor()
        cur.executescript(sql)

def seed_users(cursor, n):
    fake = Faker()
    for _ in range(n):
        fullname = fake.name()
        email = fake.unique.email()
        cursor.execute("INSERT INTO users (fullname, email) VALUES (?, ?)", (fullname, email))

def seed_tasks(cursor, n):
    fake = Faker()
    cursor.execute("SELECT id FROM users")
    user_ids = [row[0] for row in cursor.fetchall()]

    cursor.execute("SELECT id FROM status")
    status_ids = [row[0] for row in cursor.fetchall()]

    for _ in range(n):
        title = fake.sentence(nb_words=6)
        description = fake.text(max_nb_chars=200)
        status_id = random.choice(status_ids)
        user_id = random.choice(user_ids)
        cursor.execute("INSERT INTO tasks (title, description, status_id, user_id) VALUES (?, ?, ?, ?)",
                       (title, description, status_id, user_id))

def seed_database():
    with sqlite3.connect('main.db') as con:
        cursor = con.cursor()
        seed_users(cursor, 10)
        seed_tasks(cursor, 30)
        con.commit()

if __name__ == "__main__":
    create_db()
    seed_database()

